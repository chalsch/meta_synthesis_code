###################################################################
###################################################################

# Code for "Meta-synthesis reveals interconnections
# among drivers of insect biodiversity loss"

# Author: Chris Halsch
# Date: February 5, 2025

# Below you will find the code for generating the figures. Each block can be run 
# on its own and I recommenced clearing libraries between figures.

# All packages used:

# circlize
# dplyr
# forcats
# ggplot2
# ggrepel
# ggsankey
# igraph
# microbiome
# stringr
# tidyr

# ggsankey is not available on CRAN; to install it please run
# devtools::install_github("davidsjoberg/ggsankey")

# IMPORTANT NOTE: 
# While each figure was generated in R, assembly and minor tweaking was done
# post-hoc in Inkscape for aesthetics.

# Line 47: Figure 1A
# Line 188: Figure 1B
# Line 266: Figure 2
# Line 378: Figure 3
# Line 478: Figure 4
# Line 724: Figure 5A
# Line 837: Figure 5B
# Line 904: Figure 5C

###################################################################
###################################################################

#setwd(".../data_share_new/")

# ##################################### #
##########      Figure 1A      ##########
# ##################################### #

library(dplyr)
library(ggplot2)
library(ggsankey)
library(igraph)
library(microbiome)
library(stringr)
library(tidyr)

# import data
dat <- read.csv("cleaned_paths.csv") 
# removes two categories that are rarely mentioned
dat <- dat %>%
  filter(pred_Main_driver != "overexploitation" & pred_Main_driver != "other") %>%
  filter(res_Main_driver != "overexploitation" & res_Main_driver != "other")

# import terms at different resolutions and format them to be joined
term_groups <- read.csv("~/Documents/MANUSCRIPTS/review_of_reviews/term_groups.csv")
term_groups <- term_groups %>% select(Main_driver, Sub2, Sub1)
colnames(term_groups)[2] <- "Driver.type"
term_groups <- data.frame(apply(term_groups, 2, tolower))
term_groups <- distinct(term_groups)

# idk... why not? beats having to reimport
dat1 <- dat

summ1 <- dat1 %>%
  select(pred_Sub2, res_Sub2, pred_Sub2_ult, res_Sub2_ult, everything())

# name columns to make it an igraph object
colnames(summ1)[1:2] <- c("from", "to")

# make an igraph object
g <- graph_from_data_frame(summ1, directed = T)

# extract verticies and join with term names
verts <- data.frame(Driver.type = names(V(g)))
verts <- left_join(verts, term_groups)

# this next for loop goes over all node combinations and counts the links between them
outcomes <- verts$Driver.type[which(verts$Main_driver %in% c("colony", "community interactions", "genetics", "individual", "population"))]
predictors <- verts$Driver.type[-which(verts$Main_driver %in% c("colony", "community interactions", "genetics", "individual", "population"))]

out <- data.frame(Predictor = NA, Outcome = NA, num_paths = NA)
for (i in 1:length(outcomes)) {
  for (j in 1:length(predictors)) {
    temp <- data.frame(Predictor = predictors[j],
                       Outcome = outcomes[i],
                       num_paths = length(all_simple_paths(g, from = predictors[j], to = outcomes[i], cutoff = 1)))
    out <- rbind(out, temp)
  }
  print(i)
}
out <- out[-1,]

# this output is then formatted and joined with the different resolution term names
predictor_names <- term_groups
colnames(predictor_names) <- c("Pred_main_driver", "Predictor", "Predictor1")
outcome_names <- term_groups
colnames(outcome_names) <- c("Outcome_main_driver", "Outcome", "Outcome1")

out <- left_join(out, predictor_names, by = "Predictor")
out <- left_join(out, outcome_names, by = "Outcome")

out1 <- out

# this calculates the eveness of each relationship, the calues are used in the final figure
even <- out1 %>% 
  filter(num_paths > 0) %>% 
  group_by(Outcome_main_driver, Pred_main_driver) %>% 
  summarise(tot=sum(num_paths)) %>% 
  spread(key = Outcome_main_driver, value = tot, fill = 0)

evenness(even[,2:6])

# the rest of the code (pre ggplot) puts the data into the format that ggsankey wants
nodes1 <- data.frame(name=c(sort(as.character(out1$Pred_main_driver), decreasing = T), rev(c("community interactions",  "population", "colony", "individual", "genetics")))) %>% unique()

out1$node=match(out1$Pred_main_driver, nodes1$name)-1
out1$next_node=match(out1$Outcome_main_driver, nodes1$name)-1
out1 <- data.frame(out1)
out1$x <- "Driver"
out1$next_x <- "Outcome"
out1$x <- factor(out1$x, levels = c("Driver", "Outcome"))
out1$next_x <- factor(out1$next_x, levels = c("Driver", "Outcome"))

out1 <- out1 %>% filter(num_paths > 0)
outlist <- list()
counter <- 0
for (i in 1:nrow(out1)) {
  temp <- out1[i,]
  for (j in 1:temp$num_paths[1]) {
    counter <- counter + 1
    outlist[[counter]] <- temp
  }
}
out2 <- data.table::rbindlist(outlist)
out2 <- out2 %>% select(x, next_x, node, next_node)

outlist <- list()
for (i in 1:nrow(out2)) {
  temp <- out2[i,]
  temp_out <- rbind(temp, data.frame(x = "Outcome", next_x = NA, node = temp$next_node[1], next_node = NA))
  outlist[[i]] <- temp_out
}

out1 <- data.table::rbindlist(outlist)
out1 <- left_join(out1, data.frame(node = 0:14, node_name = str_to_title(nodes1$name)))
out1 <- out1 %>% filter(is.na(node)==F)
out1 <- out1 %>% 
  mutate(node_name = recode(node_name,
                            Colony = "Colony\n0.79",
                            `Community Interactions` = "Community Interactions\n0.92",
                            Genetics = "Genetics\n0.91",
                            Individual = "Individual\n0.66",
                            Population = "Population\n0.84"))

#pdf(file = "~/Documents/MANUSCRIPTS/review_of_reviews/sank.pdf", width = 8, height = 10)
#svglite("~/Documents/MANUSCRIPTS/review_of_reviews/sank.svg", width = 8, height = 10)

ggplot(out1, aes(x = x, next_x = next_x, node = node, next_node = next_node, fill = factor(node), label = node_name)) +
  geom_sankey(flow.alpha = 0.5 , node.color = "black", show.legend = FALSE) +
  geom_sankey_text(aes(alpha = ifelse(node >= 10, 0, 1)), size = 5, show.legend = F, position = position_nudge(0.06,0), hjust = 0, fontface = "bold") +
  geom_sankey_text(data = subset(out1, node >= 10), size = 5, show.legend = F, position = position_nudge(-0.06,0), hjust = 1, fontface = "bold") +
  #geom_rect(aes(x = 1, y=1), color = "white") +
  scale_fill_manual(values = c("#7F7F7F", "#ff85b4", "#6584d2", "#b393b8", "#ffd604", "#6cd992", "#5cced1", "#cc7a66", "#FF6E42", "#a687d6",
                               "#ffffff", "#ffffff", "#ffffff", "#ffffff", "#ffffff")) +
  theme_sankey(base_size = 15) +
  theme(axis.title = element_blank(),
        axis.text = element_blank(), 
        plot.margin = unit(c(-1,-9.75,-1,-9.75), "cm"))

dev.off()

# ############################################################### #
# ############################################################### #

# ##################################### #
##########      Figure 1B      ##########
# ##################################### #

library(circlize)
library(dplyr)

# import data
dat <- read.csv("cleaned_paths.csv") 

taxa_groups <- read.csv("taxa_table.csv")
taxa_groups$TAXA_TERM <- tolower(taxa_groups$TAXA_TERM)

remove <- c("colony", "community interactions", "genetics", "individual", "other", "population")

# put into chord diagram format
to_chord <- dat %>% 
  left_join(taxa_groups, by = "TAXA_TERM") %>% 
  select(pred_Main_driver, res_Main_driver) %>% 
  group_by(pred_Main_driver, res_Main_driver) %>% 
  summarise(value = n()) %>% 
  rename(from = pred_Main_driver, to = res_Main_driver) %>% 
  filter(! from %in% remove) %>% 
  filter(! to %in% remove) %>% 
  filter(to != from) %>% 
  mutate(from = paste(toupper(substr(from, 1, 1)), substr(from, 2, nchar(from)), sep=""),
         to = paste(toupper(substr(to, 1, 1)), substr(to, 2, nchar(to)), sep=""),
         from = recode(from, Overexploitation = "Overexploit."),
         to = recode(to, Overexploitation = "Overexploit."),
         from = recode(from, `Non-native species` = "Non-native sp."),
         to = recode(to, `Non-native species` = "Non-native sp.")) %>% 
  filter(from != "Overexploit." & to != "Overexploit.")

# colors
grid.col = c(Agriculture = "#a687d6",
             Climate = "#FF6E42",
             Disturbance = "#cc7a66",
             `Habitat quality` = "#5cced1",
             `Other industry` = "#b393b8",
             `Land use change` = "#6cd992",
             `Non-native sp.` = "#ffd604",
             #`Overexploit.` = "#ff8f7d",
             Pathogens = "#6584d2",
             Pollution = "#ff85b4",
             Urbanization = "#7F7F7F")

#pdf(file = "~/Documents/MANUSCRIPTS/review_of_reviews/circle.pdf",   # The directory you want to save the file in
#    width = 8, # The width of the plot in inches
#    height = 8)
#svglite("~/Documents/MANUSCRIPTS/review_of_reviews/circle.svg", width = 8, height = 8)

group <- as.character(factor(sort(unique(c(to_chord$to, to_chord$from)))))
names(group) <- group

circos.par(start.degree = 90)
chordDiagram(to_chord, grid.col = grid.col, group = group,
             link.lwd = 1, link.border = NA, annotationTrack = c("grid"), 
             preAllocateTracks = list(track.height = max(strwidth(unlist(dimnames(to_chord))))))

circos.track(track.index = 1, panel.fun = function(x, y) {
  circos.text(CELL_META$xcenter, 0.8, CELL_META$sector.index, cex = 0.85,
              facing = "bending.inside", niceFacing = FALSE, adj = c(0.5, 0.5), font = 2)
  circos.axis(h = 'bottom',
              #major.at = c(0,5,10,15,20,25,30,35,40,45,50),
              #labels = c(0,5,10,15,20,25,30,35,40,45,50),
              #major.tick.length = 2,
              minor.ticks = 1,
              labels.cex = 0.75,
              sector.index = CELL_META$sector.index,
              track.index = 1,
              labels.niceFacing = FALSE)
}, bg.border = NA) # here set bg.border to NA is important

circos.clear()
dev.off()

# ############################################################### #
# ############################################################### #

# ##################################### #
##########      Figure 2      ###########
# ##################################### #

library(dplyr)
library(igraph)
library(tidyr)

# import and format data
dat <- read.csv("cleaned_paths.csv")
dat$Taxa <- tolower(dat$TAXA_TERM)
dat <- subset(dat, Type_of_mention != "passing")

term_groups <- read.csv("term_groups.csv") 
term_groups <- data.frame(apply(term_groups, 2, tolower))
term_groups <- term_groups %>% select(-n, -Sub3)

insect.terms <- term_groups[term_groups$Main_driver%in%c("individual", "colony", "genetics", "community interaction"),]
sub.terms <- unique(insect.terms$Sub2)
for(i in 1:length(sub.terms)){
  dat$res_Sub2[dat$res_Sub2==sub.terms[i]] <- unique(insect.terms$Main_driver[insect.terms$Sub2==sub.terms[i]])
  dat$pred_Sub2[dat$pred_Sub2==sub.terms[i]] <- unique(insect.terms$Main_driver[insect.terms$Sub2==sub.terms[i]])
}

# turn into network
summ1 <- dat %>%
  select(pred_Sub2, res_Sub2)

colnames(summ1)[1:2] <- c("from", "to")

g <- graph_from_data_frame(summ1, directed = T)

summ1$path <- paste(summ1$from, summ1$to, sep="|")

# format igraph for plotting
e.names <- attributes(E(g))$vnames
e.weights <- as.numeric(table(e.names)[match(e.names, names(table(e.names)))])
grid.col = c(agriculture = "#a687d6",
             climate = "#FF6E42", 
             disturbance = "#cc7a66", 
             `other industry` = "#b393b8",
             `land use change` = "#6cd992", 
             `habitat quality` ="#5cced1",
             `non-native species` = "#ffd604",
             overexploitation = "#dadada", 
             pathogens = "#6584d2", 
             pollution = "#ff85b4", 
             urbanization = "#7F7F7F",
             response="#ffffff",
             other="#dadada"
)

grid.col2 <- paste(grid.col, "88", sep="")
names(grid.col2) <- names(grid.col)
grid.col <- grid.col2
v.names <- attributes(V(g))$names
v.class <- term_groups$Main_driver[match(v.names, term_groups$Sub2)]
v.class[v.names=="response"] <- "response"
v.class[v.names=="individual"] <- "response"
v.class[v.class%in%c("individual", "colony", "genetics",
                     "community interactions", "population")] <- "response"
v.col <- grid.col[match(v.class, names(grid.col))]

new.order <- order(as.numeric(factor(v.col)))

n.ord <- c(54, 18, 65, 21, 43, 44, 61, 42, 64, 16, 83, 77, 75, 68, 40,
           14, 32, 37, 28, 36, 4, 20, 76, 74, 70, 63, 67, 55, 26, 27, 23,
           22, 17, 88, 87, 8, 69, 13, 12, 11, 1, 2, 45, 53, 50, 41, 49,
           52, 33, 86, 79, 24, 15, 73, 62, 19, 3, 57, 25, 84, 51, 38, 72,
           60, 39, 31, 34, 85, 58, 56, 66, 35, 30, 71, 10, 89, 82, 59, 46,
           29, 80, 47, 48, 5, 9, 78, 6, 7, 81)

g2 <- igraph::permute(g, n.ord)

v.names <- attributes(V(g2))$names
v.class <- term_groups$Main_driver[match(v.names, term_groups$Sub2)]
v.class[v.names=="response"] <- "response"
v.class[v.names=="individual"] <- "response"
v.class[v.class%in%c("individual", "colony", "genetics",
                     "community interactions", "population")] <- "response"
v.col <- grid.col[match(v.class, names(grid.col))]

#pdf(file = "~/Documents/MANUSCRIPTS/review_of_reviews/circle_compl.pdf",   # The directory you want to save the file in
#    width = 8, # The width of the plot in inches
#    height = 8)

#svglite("~/Documents/MANUSCRIPTS/review_of_reviews/circle_compl.svg", width = 8, height = 8)


# plots network, labels moved outside of R
v.f <- v.col
v.f[v.col=="#ffffff88"] <- "#cacacadd"
igraph::plot.igraph(
  igraph::simplify(g2), 
  layout=layout.circle(g2),
  edge.arrow.size = 0,
  edge.color = "#cacaca50",
  edge.width=sqrt(e.weights)/2,
  vertex.color = v.col,
  vertex.frame.color = v.f,
  vertex.label.family = "Helvetica",
  vertex.label.dist = 0,
  vertex.label.color = "black",
  vertex.size = sqrt(igraph::degree(g2, mode = "all")/2),
  vertex.label.cex=0.65
)

dev.off()

# ############################################################### #
# ############################################################### #

# #################################### #
##########      Figure 3      ##########
# #################################### #

library(dplyr)
library(ggplot2)
library(ggrepel)
library(igraph)
library(tidyr)

# import data
dat <- read.csv("cleaned_paths.csv") 
dat <- dat %>%
  filter(pred_Main_driver != "overexploitation" & pred_Main_driver != "other") %>%
  filter(res_Main_driver != "overexploitation" & res_Main_driver != "other")

term_groups <- read.csv("term_groups.csv")
term_groups <- term_groups %>% select(Main_driver, Sub2, Sub1)
colnames(term_groups)[2] <- "Driver.type"
term_groups <- data.frame(apply(term_groups, 2, tolower))
term_groups <- distinct(term_groups)

# colors
colors <- data.frame(Main_driver = sort(unique(c(dat$pred_Main_driver, dat$res_Main_driver))))
colors$color <- c("#a687d6", "#ff7e52", "#ffffff", "#ffffff", "#cc7a66", "#ffffff", "#5cced1", 
                  "#ffffff", "#6cd992", "#ffd604", "#b393b8",
                  "#6584d2", "#ff85b4", "#ffffff","#7F7F7F")

# look at highest resolution nodes and turn into a graph
dat1 <- dat

summ1 <- dat1 %>%
  select(pred_Sub2, res_Sub2) %>% distinct()

colnames(summ1)[1:2] <- c("from", "to")

g <- graph_from_data_frame(summ1, directed = T)

# seperate nodes based on predictors and outcomes
verts <- data.frame(Driver.type = names(V(g)))
verts <- left_join(verts, term_groups)
colnames(verts)[1] <- "Predictor"

outcomes <- verts$Predictor[which(verts$Main_driver %in% c("colony", "community interactions", "genetics", "individual", "population"))]
predictors <- verts$Predictor[-which(verts$Main_driver %in% c("colony", "community interactions", "genetics", "individual", "population"))]

# generate summary statistics for connections for each node (same stats used in paper)
between <- data.frame(betweenness(g, directed = T))
closeness <- data.frame(closeness(g))
eigenvector_scores <- data.frame(eigen_centrality(g, directed = T))

degree <- dat1 %>%
  select(pred_Sub2, res_Sub2) %>% 
  mutate(Driver.type = 1) %>% 
  gather(key = "var", value = Driver.type) %>% 
  group_by(Driver.type) %>% 
  summarise(degree = n())

# combine stats into one plotting data frame
tst <- data.frame(node = V(g),
                  Driver.type = names(V(g)),
                  between = between$betweenness.g..directed...T.,
                  close = closeness$closeness.g., 
                  #egree = degree$degree.g..loops...F...,
                  eigne = eigenvector_scores$vector)

tst <- left_join(tst, term_groups)
tst <- left_join(tst, colors)
tst <- left_join(tst, degree)
tst <- subset(tst, degree >= 10)

tst <- tst %>% filter(Driver.type %in% predictors)
tst$to_label <- ifelse(tst$degree >= 100 | tst$between >= 100, 1, 0)
tst$scale_between <- scale(tst$between)[,1]
tst$scale_degree <- scale(tst$degree)[,1]

ggplot() +
  geom_abline(slope = 1, linetype = "dashed") +
  geom_point(data = tst, aes(x=scale_between, y=scale_degree, fill = color), size = 7, pch = 21, color = "black", show.legend = F) +
  geom_label_repel(data = subset(tst, tst$to_label == 1),
                   aes(x=scale_between, y=scale_degree, label = Driver.type),
                   label.padding =  unit(0.15, "lines"),
                   min.segment.length = 0,
                   #nudge_y = -10,
                   #nudge_x = 10,
                   size = 5.5, force = 1) +
  scale_fill_identity() +
  labs(x = "Betweeness centrality", y = "Frequency") +
  theme_classic() +
  theme(axis.title = element_text(face = "bold", size = 18),
        axis.text = element_text(size = 15))

#ggsave("~/Documents/MANUSCRIPTS/review_of_reviews/scatter.pdf", width = 8, height = 8)
#ggsave("~/Documents/MANUSCRIPTS/review_of_reviews/scatter.svg", width = 8, height = 8)

dev.off()

# ############################################################### #
# ############################################################### #

# #################################### #
##########      Figure 4      ##########
# #################################### #

library(dplyr)
library(ggplot2)
library(ggrepel)
library(tidyr)

dat <- read.csv("cleaned_paths.csv")

grid.col <- data.frame(cols = c("#a687d6", "#FF6E42", "#cc7a66", "#b393b8", "#6cd992", "#5cced1", "#ffd604",
                                "#dadada", "#6584d2", "#ff85b4", "#7F7F7F", "#ffffff", "#dadada"),
                       Main_driver = c("agriculture", "climate", "disturbance", "other industry", "land use change", "habitat quality", "non-native species",
                                       "overexploitation", "pathogens", "pollution", "urbanization", "Response", "other"))

# this breaks the data into paths that specifically mention each family
dat1 <- dat[grepl("Hymenoptera", dat$taxa_tags, ignore.case = TRUE), ]
dat1$family <- "Hymenoptera"
dat2 <- dat[grepl("Diptera", dat$taxa_tags, ignore.case = TRUE), ]
dat2$family <- "Diptera"
dat3 <- dat[grepl("Coleoptera", dat$taxa_tags, ignore.case = TRUE), ]
dat3$family <- "Coleoptera"
dat4 <- dat[grepl("Lepidoptera", dat$taxa_tags, ignore.case = TRUE), ]
dat4$family <- "Lepidoptera"
dat5 <- dat[grepl("Odonata", dat$taxa_tags, ignore.case = TRUE), ]
dat5$family <- "Odonata"
dat6 <- dat[grepl("Orthoptera", dat$taxa_tags, ignore.case = TRUE), ]
dat6$family <- "Orthoptera"
dat7 <- dat[grepl("Hemiptera", dat$taxa_tags, ignore.case = TRUE), ]
dat7$family <- "Hemiptera"
datc <- rbind(dat1, dat2, dat3, dat4, dat5, dat6, dat7)

# merge repsonse and predictor variables
summ1 <- datc %>%
  select(res_Sub2, res_Main_driver) 
colnames(summ1) <- c("Driver.type", "Main_driver")

summ2 <- datc %>%
  select(pred_Sub2, pred_Main_driver)
colnames(summ2) <- c("Driver.type", "Main_driver")
summ <- rbind(summ1, summ2)

# this calculates the number of mentions and arranges by driver type and number of mentions
summ <- summ %>% 
  group_by(Driver.type, Main_driver) %>% 
  summarise(Degree = n()) %>% 
  arrange(Main_driver, Degree)
summ$order <- 1:nrow(summ)

# this next bit summarizes the proportion of each node in whatever is the majority taxa
dsumm1 <- datc %>%
  select(res_Sub2, res_Main_driver, family) 
colnames(dsumm1) <- c("Driver.type", "Main_driver", "family")

dsumm2 <- datc %>%
  select(pred_Sub2, pred_Main_driver, family)
colnames(dsumm2) <- c("Driver.type", "Main_driver", "family")
dsumm <- rbind(dsumm1, dsumm2)

datcc <- dsumm %>% 
  group_by(Driver.type, family) %>% 
  summarise(n = n()) %>% 
  spread(key = family, value = n, fill = 0) %>% 
  distinct()

datcc$div <- vegan::diversity(datcc[,2:8], index = "invsimpson")

datcc <- left_join(datcc, summ)
datcc$prop_main <- NA
datcc$main_cat <- NA

# warning message occurs when there is an equal split between groups (Coleo/Lepid in both cases)
# both instances are assigned to coleoptera
for (i in 1:nrow(datcc)) {
  prop <- max(datcc[i,2:8]) / sum(datcc[i,2:8])
  cat <- which(datcc[i,2:8] == max(datcc[i,2:8]))
  datcc$prop_main[i] <- prop
  datcc$main_cat[i] <- colnames(datcc)[cat+1]
}

# group all outcomes together so1 they are recoded
plot <- datcc %>% 
  #filter(div > 1) %>% 
  mutate(Main_driver = recode(Main_driver,
                              population = "Response",
                              individual = "Response",
                              colony = "Response",
                              `community interactions` = "Response",
                              genetics = "Response")) %>% 
  arrange(main_cat, Main_driver, prop_main) %>% 
  left_join(grid.col)

# now I use polar coordinate to cartesian coordinate converstion to gey the x,y locations of each node
plot$cir_order <- 1:nrow(plot)
plot$cir_order_stretch <- scales::rescale(plot$cir_order, to = c(5, 355))
plot$theta_radians <- plot$cir_order_stretch * pi / 180
plot$x <- 0 + plot$prop_main  * cos(plot$theta_radians)
plot$y <- 0 + plot$prop_main * sin(plot$theta_radians)
plot$x_orig <- 0 + 0.25  * cos(plot$theta_radians)
plot$y_orig <- 0 + 0.25 * sin(plot$theta_radians)
plot$label <- ifelse(plot$prop_main >= 0.9, 1, 0)
plot$label.x <- 0.05 + plot$prop_main  * cos(plot$theta_radians)
plot$label.y <- 0.05 + plot$prop_main * sin(plot$theta_radians)

# these calculations determine the edges of each taxa group on the plot. These are used to place
# the side of the slices
x.position.lab.1 <- cos(plot$theta_radians[13])
y.position.lab.1 <- sin(plot$theta_radians[13])

x.position.lab.2 <- cos(plot$theta_radians[14])
y.position.lab.2 <- sin(plot$theta_radians[14])

x.position.lab.3 <- cos(plot$theta_radians[88])
y.position.lab.3 <- sin(plot$theta_radians[88])

x.position.lab.4 <- cos(plot$theta_radians[89])
y.position.lab.4 <- sin(plot$theta_radians[89])

x.position.lab.5 <- cos(plot$theta_radians[97])
y.position.lab.5 <- sin(plot$theta_radians[97])

x.position.lab.6 <- cos(plot$theta_radians[1])
y.position.lab.6 <- sin(plot$theta_radians[1])

# these determine the circular border around each taxa piece
arc_hymenoptera <- data.frame(x = 1.05  * cos(seq(from = plot$theta_radians[14],
                                                  to = plot$theta_radians[88],
                                                  length.out = 100)),
                              y = 1.05  * sin(seq(from = plot$theta_radians[14],
                                                  to = plot$theta_radians[88],
                                                  length.out = 100)))

arc_lepid <- data.frame(x = 1.05  * cos(seq(from = plot$theta_radians[89],
                                            to = plot$theta_radians[97],
                                            length.out = 100)),
                        y = 1.05  * sin(seq(from = plot$theta_radians[89],
                                            to = plot$theta_radians[97],
                                            length.out = 100)))

arc_coleo <- data.frame(x = 1.05  * cos(seq(from = plot$theta_radians[1],
                                            to = plot$theta_radians[13],
                                            length.out = 100)),
                        y = 1.05  * sin(seq(from = plot$theta_radians[1],
                                            to = plot$theta_radians[13],
                                            length.out = 100)))

# these determine the circular dashed lines for 50%, 70%, 90%
arc_90 <- data.frame(x = 0.9  * cos(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)),
                     y = 0.9  * sin(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)))

arc_70 <- data.frame(x = 0.7  * cos(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)),
                     y = 0.7  * sin(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)))

arc_50 <- data.frame(x = 0.5  * cos(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)),
                     y = 0.5  * sin(seq(from = min(plot$theta_radians),
                                        to = max(plot$theta_radians),
                                        length.out = 100)))

# place locations of 50, 70, and 90% labels
arc_labs <- data.frame(x = c(0.5 * cos(0), 0.7 * cos(0), 0.9 * cos(0)),
                       y = c(0.5 * sin(0), 0.7 * sin(0), 0.9 * sin(0)),
                       lab = c("50%", "70%", "90%"))

# cartesian to polar function
cart2polar <- function(x, y) {
  data.frame(r = sqrt(x^2 + y^2), theta = atan2(y, x))
}

x_seq <- seq(min(plot$x)-0.25, max(plot$x)+0.25, length.out = 1000)
y_seq <- seq(min(plot$y)-0.25, max(plot$y)+0.25, length.out = 1000)
empty_grid <- expand.grid(x=x_seq, y=y_seq)
out <- cart2polar(empty_grid$x, empty_grid$y)

# all of this figures out the light gray background. plotted as a raster in the final plot. 
hymenoptera_bound_start <- cart2polar(cos(plot$theta_radians[14]), sin(plot$theta_radians[14]))
hymenoptera_bound_end <- cart2polar(cos(plot$theta_radians[88]), sin(plot$theta_radians[88])) 
hymen_poly <- cbind(empty_grid, out)
hymen_poly$col <- ifelse(hymen_poly$theta > hymenoptera_bound_start[1,2] | hymen_poly$theta < hymenoptera_bound_end[1,2], 1, 0)
hymen_poly <- subset(hymen_poly, col == 1)
hymen_poly$col <- ifelse(hymen_poly$r < 1.05, 1, 0)
hymen_poly <- subset(hymen_poly, col == 1)

lepid_bound_start <- cart2polar(cos(plot$theta_radians[89]), sin(plot$theta_radians[89]))
lepid_bound_end <- cart2polar(cos(plot$theta_radians[97]), sin(plot$theta_radians[97])) 
lepid_poly <- cbind(empty_grid, out)
lepid_poly$col <- ifelse(lepid_poly$theta > lepid_bound_start[1,2] & lepid_poly$theta < lepid_bound_end[1,2], 1, 0)
lepid_poly <- subset(lepid_poly, col == 1)
lepid_poly$col <- ifelse(lepid_poly$r < 1.05, 1, 0)
lepid_poly <- subset(lepid_poly, col == 1)

coleo_bound_start <- cart2polar(cos(plot$theta_radians[1]), sin(plot$theta_radians[1]))
coleo_bound_end <- cart2polar(cos(plot$theta_radians[13]), sin(plot$theta_radians[13])) 
coleo_poly <- cbind(empty_grid, out)
coleo_poly$col <- ifelse(coleo_poly$theta > coleo_bound_start[1,2] & coleo_poly$theta < coleo_bound_end[1,2], 1, 0)
coleo_poly <- subset(coleo_poly, col == 1)
coleo_poly$col <- ifelse(coleo_poly$r < 1.05, 1, 0)
coleo_poly <- subset(coleo_poly, col == 1)

# final plot, uncomment the labels for supplemental labeled plot
ggplot() +
  geom_raster(data = hymen_poly, aes(x,y), fill = "gray95") +
  geom_raster(data = lepid_poly, aes(x,y), fill = "gray95") +
  geom_raster(data = coleo_poly, aes(x,y), fill = "gray95") +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.1*1.05, yend = y.position.lab.1*1.05), color = "black", linewidth = 0.75) +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.2*1.05, yend = y.position.lab.2*1.05), color = "black", linewidth = 0.75) +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.3*1.05, yend = y.position.lab.3*1.05), color = "black", linewidth = 0.75) +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.4*1.05, yend = y.position.lab.4*1.05), color = "black", linewidth = 0.75) +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.5*1.05, yend = y.position.lab.5*1.05), color = "black", linewidth = 0.75) +
  geom_segment(aes(x = 0, y = 0, xend = x.position.lab.6*1.05, yend = y.position.lab.6*1.05), color = "black", linewidth = 0.75) +
  geom_path(data = arc_hymenoptera, aes(x=x, y=y), linewidth = 0.75) +
  geom_path(data = arc_coleo, aes(x=x, y=y), linewidth = 0.75) +
  geom_path(data = arc_lepid, aes(x=x, y=y), linewidth = 0.75) +
  geom_path(data = arc_90, aes(x=x, y=y), linewidth = 0.5, linetype = "dashed") +
  geom_path(data = arc_70, aes(x=x, y=y), linewidth = 0.5, linetype = "dashed") +
  geom_path(data = arc_50, aes(x=x, y=y), linewidth = 0.5, linetype = "dashed") +
  geom_segment(data = plot, aes(x = x_orig, y = y_orig, xend = x, yend = y), color = "black", linewidth = 0.5, linetype = "solid") +
  # geom_point(data = plot, aes(0,0), color = "black", size = 10) +
  geom_point(data = plot, aes(x,y, fill = cols), pch = 21, show.legend = F, size = 5) +
  geom_text(data = arc_labs, aes(x,y, label = lab), fontface = "bold", size = 6) +
  #geom_label_repel(data = subset(plot, x > 0 & y > 0), aes(x,y, label = Driver.type), size = 2.25, nudge_x = 0.05, nudge_y = 0.05) +
  #geom_label_repel(data = subset(plot, x > 0 & y < 0), aes(x,y, label = Driver.type), size = 2.25, nudge_x = 0.05, nudge_y = -0.05) +
  #geom_label_repel(data = subset(plot, x < 0 & y > 0), aes(x,y, label = Driver.type), size = 2.25, nudge_x = -0.05, nudge_y = 0.05) +
  #geom_label_repel(data = subset(plot, x < 0 & y < 0), aes(x,y, label = Driver.type), size = 2.25, nudge_x = -0.05, nudge_y = -0.05) +
  scale_fill_identity() +
  theme_void() +
  theme(plot.margin = unit(c(0,0,0,0), "cm"))

#ggsave("~/Documents/MANUSCRIPTS/review_of_reviews/bias_label.pdf", width = 8, height = 8)
#ggsave("~/Documents/MANUSCRIPTS/review_of_reviews/bias.svg", width = 8, height = 8)

dev.off()

# ############################################################### #
# ############################################################### #

# ##################################### #
##########      Figure 5A      ##########
# ##################################### #

library(dplyr)
library(forcats)
library(ggplot2)
library(tidyr)

# import IUCN terms (with codes)
IUCN_terms <- read.csv("IUCN_terms.csv")
IUCN_terms <- IUCN_terms %>% mutate(code = as.character(code))

# import the main dat with IUCN categories attached
dat <- read.csv("pathways_w_IUCN.csv")

# calculate how many occurrences between predictors and response
specific_summ <- dat %>% 
  group_by(pred.IUCN.EBV, res.IUCN.EBV, pred.type, res.type) %>% 
  summarise(n = n()) %>% 
  filter(res.type == "Outcome") %>% 
  ungroup() %>% 
  select(-pred.type, -res.type)

# now we build the empty grid of all pairwise comparisons
pred.IUCN.EBV <- unique(subset(IUCN_terms, type == "Stressor")[,2])
res.IUCN.EBV <- unique(subset(IUCN_terms, type == "Outcome")[,2])
grid <- expand_grid(pred.IUCN.EBV, res.IUCN.EBV)

# link empty grid to occurences above. 0 occurrences is NA
grid <- grid %>% 
  filter(pred.IUCN.EBV != res.IUCN.EBV) %>% 
  left_join(specific_summ, by = c("pred.IUCN.EBV", "res.IUCN.EBV")) %>% 
  rename(term = pred.IUCN.EBV) %>% 
  left_join(IUCN_terms, by = "term") %>% 
  rename(pred.IUCN.EBV = term, term = res.IUCN.EBV) %>% 
  left_join(IUCN_terms, by = "term") %>% 
  rename(res.IUCN.EBV = term) %>% 
  select(-type.x, -type.y)

# for ordering broad groups
pred_groups <- data.frame(broad.x = unique(grid$broad.x),
                          pred_order = c(1,2,3,4,5,6,7,8,9,10,11,12,13))
res_groups <- data.frame(broad.y = unique(grid$broad.y),
                         res_order = c(1,3,2,4,5,6))
plotgrid <- grid %>% 
  left_join(pred_groups) %>% 
  left_join(res_groups) %>% 
  mutate(pred.IUCN.EBV = fct_reorder(factor(pred.IUCN.EBV), pred_order),
         res.IUCN.EBV = fct_reorder(factor(res.IUCN.EBV), res_order))

# manual labels
labsx1 <- rep("", 27)
labsx1[c(3,8,13,17,21,25)] <- c("Genetic\ncomposition", "      Species\ntraits", "Species\npopulations",
                                "Community\ncomposition", "      Ecosystem\n      functioning", "        Ecosystem\n       structure")
labsx2 <- levels(plotgrid$res.IUCN.EBV)

labsy2 <- levels(plotgrid$pred.IUCN.EBV)

labsy1 <- rep("", length(levels(plotgrid$pred.IUCN.EBV)))
labsy1[c(2,7,11,16,21,25,30,35,42,47,52,57,61)] <- c("Residential &\ncommercial\ndevelopment\n", "Agriculture &\naquaculture", "Energy production\n& mining\n", "Transportation &\nservice corridors", "Biological\nresource use",
                                                     "Human intrusions\n& disturbance\n", "\nNatural system\nmodifications", "Invasive & other\nproblematic species,\ngenes & diseases", "Pollution", "Geological\nevents\n",
                                                     "Climate change &\nsevere weather", "Ecosystem/\ncommunity stresses\n", "Species\nstresses\n")

# colors
cols <- colorRampPalette(c("#F5EADE", "#60798C"))
colvec <- cols(50)

ggplot(data = plotgrid) +
  geom_tile(aes(res.IUCN.EBV, pred.IUCN.EBV, fill = n), color = "gray90", show.legend = T) +
  geom_hline(aes(yintercept = 4.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 9.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 13.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 18.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 23.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 27.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 31.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 38.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 45.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 49.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 55.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 59.5), size = 0.5, color = "black") +
  geom_hline(aes(yintercept = 63.55), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 5.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 11.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 14.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 19.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 23.5), size = 0.5, color = "black") +
  scale_fill_gradientn(colors = colvec, na.value = "white", trans = "log", breaks = c(1, 10, 100)) +
  scale_y_discrete(labels = labsy1) +
  scale_x_discrete(labels = labsx1) +
  labs(fill = "Frequency") +
  guides(y.sec = ggh4x::guide_axis_manual(labels = labsy2, label_size = 8, angle = 0, label_family= "Helvetica"),
         x.sec = ggh4x::guide_axis_manual(labels = labsx2, label_size = 8, angle = 45, label_family = "Helvetica")) +
  coord_fixed(1) +
  theme_classic() +
  theme(
    axis.text.y = element_text(angle = 0, hjust = 1, size = 10, family = "Helvetica"),
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 10, family = "Helvetica"),
    axis.ticks = element_blank(),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    legend.position = c(-0.18,1.02),
    legend.background = element_blank(),
    legend.text = element_text(size = 11))

#plot.margin= margin(0.05,0.75,0.01,0.01,unit = "cm"))

dev.off()

# ############################################################### #
# ############################################################### #

# ##################################### #
##########      Figure 5B      ##########
# ##################################### #

library(dplyr)
library(forcats)
library(ggplot2)
library(tidyr)

# import IUCN terms (with codes)
IUCN_terms <- read.csv("IUCN_terms.csv")
IUCN_terms <- IUCN_terms %>% mutate(code = as.character(code))

# import the main dat with IUCN categories attached
dat <- read.csv("pathways_w_IUCN.csv")

# calculate how many occurrences between predictors and response
broad_summ <- dat %>% 
  group_by(pred.IUCN.EBV_broad, res.IUCN.EBV_broad, pred.type, res.type) %>% 
  summarise(n = n()) %>% 
  filter(res.type == "Outcome") %>% 
  ungroup() %>% 
  select(-pred.type, -res.type)

# identifies only the big categories and build empty grid
IUCN_trim <- IUCN_terms[-c(which(grepl("\\.", IUCN_terms$code,))),]
pred.IUCN.EBV_broad <- unique(subset(IUCN_trim, type == "Stressor")[,2])
res.IUCN.EBV_broad <- unique(subset(IUCN_trim, type == "Outcome")[,2])

ylabs <- data.frame(pred.IUCN.EBV_broad = c("Residential & commercial development", "Agriculture & aquaculture", "Energy production & mining", "Transportation & service corridors", "Biological resource use",
                                            "Human intrusions & disturbance", "Natural system modifications", "Invasive & other problematic species, genes & diseases", "Pollution", "Geological events",
                                            "Climate change & severe weather", "Ecosystem/community stresses", "Species stresses"),
                    order = 1:13)
grid <- expand_grid(pred.IUCN.EBV_broad, res.IUCN.EBV_broad)
grid <- grid %>% 
  left_join(broad_summ, by = c("pred.IUCN.EBV_broad", "res.IUCN.EBV_broad")) %>% 
  left_join(ylabs, by = "pred.IUCN.EBV_broad") %>% 
  mutate(pred.IUCN.EBV_broad = fct_reorder(factor(pred.IUCN.EBV_broad), order),
         res.IUCN.EBV_broad = factor(res.IUCN.EBV_broad))


cols <- colorRampPalette(c("#F5EADE", "#60798C"))
colvec <- cols(50)

ggplot(data = grid) +
  geom_tile(aes(res.IUCN.EBV_broad, pred.IUCN.EBV_broad, fill = n), color = "gray90", show.legend = F) +
  scale_fill_gradientn(colors = colvec, na.value = "white", trans = "log", breaks = c(1, 10, 100)) +
  labs(fill = "Frequency") +
  coord_fixed(1) +
  theme_classic() +
  theme(
    axis.text.y = element_text(angle = 0, hjust = 1, size = 10, family = "Helvetica"),
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 10, family = "Helvetica"),
    axis.ticks = element_blank(),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    legend.position = c(-0.18,1.02),
    legend.background = element_blank(),
    legend.text = element_text(size = 11))

#ggsave("IUCN_fig2.svg", width = 10, height = 4, dpi = 600)

dev.off()

# ############################################################### #
# ############################################################### #

# ##################################### #
##########      Figure 5C      ##########
# ##################################### #

library(dplyr)
library(forcats)
library(ggplot2)
library(tidyr)

# import main data, subset to only pollution
dat <- read.csv("pathways_w_IUCN.csv")
pollute <- dat %>% filter(pred.IUCN.EBV_broad == "Pollution")

# calculate how many occurrences between pollution and response
pollute_summ <- pollute %>% 
  group_by(IUCN.EBV.x, IUCN.EBV.y, pred.type, res.type) %>% 
  summarise(n = n()) %>% 
  filter(res.type == "Outcome") %>% 
  ungroup() %>% 
  select(-pred.type, -res.type)

# make labels and generate empty grid
IUCN.EBV.x <- c("Domestic & urban waste water", "Sewage", "Run-off", "Industrial & military effluents",
                "Oil spills", "Seepage from mining", "Agricultural & forestry effluents", "Nutrient loads",
                "Soil erosion, sedimentation", "Herbicides & pesticides", "Garbage & solid waste", 
                "Air-borne pollutants", "Acid rain", "Smog", "Ozone", "Excess energy", "Light pollution",
                "Thermal pollution", "Noise pollution")

IUCN.EBV.y_dat <- data.frame(IUCN.EBV.y = c("Effective population size", "Genetic composition", "Genetic differentiation", "Genetic diversity",
                                            "Inbreeding", "Morphology", "Movement", "Phenology", "Physiology", "Reproduction", "Species traits", 
                                            "Species abundances", "Species distributions", "Species populations", "Community abundance", "Community composition", 
                                            "Interaction diversity", "Taxonomic/phylogenetic diversity", "Trait diversity", "Ecosystem disturbances", "Ecosystem functioning",
                                            "Ecosystem phenology", "Primary productivity", "Ecosystem distribution", "Ecosystem structure", "Ecosystem Vertical Profile", "Live cover fraction"),
                             order = 1:27)

grid <- expand_grid(IUCN.EBV.x, IUCN.EBV.y_dat$IUCN.EBV.y)
colnames(grid)[2] <- "IUCN.EBV.y"
grid <- grid %>% 
  left_join(pollute_summ, by = c("IUCN.EBV.x", "IUCN.EBV.y")) %>% 
  left_join(IUCN.EBV.y_dat, by = "IUCN.EBV.y") %>% 
  mutate(IUCN.EBV.x = as.factor(IUCN.EBV.x),
         IUCN.EBV.y = fct_reorder(factor(IUCN.EBV.y), order))


labsx2 <- levels(grid$IUCN.EBV.y)
labsy2 <- levels(grid$IUCN.EBV.x)

cols <- colorRampPalette(c("#F5EADE", "#60798C"))
colvec <- cols(50)

ggplot(data = grid) +
  geom_tile(aes(IUCN.EBV.y, IUCN.EBV.x, fill = n), color = "gray90", show.legend = F) +
  geom_vline(aes(xintercept = 5.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 11.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 14.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 19.5), size = 0.5, color = "black") +
  geom_vline(aes(xintercept = 23.5), size = 0.5, color = "black") +
  scale_fill_gradientn(colors = colvec, na.value = "white", trans = "log", breaks = c(1, 10, 100)) +
  labs(fill = "Frequency") +
  guides(y.sec = ggh4x::guide_axis_manual(labels = labsy2, label_size = 7, angle = 0, label_family= "Helvetica", color = "black"),
         x.sec = ggh4x::guide_axis_manual(labels = labsx2, label_size = 7, angle = 45, label_family = "Helvetica", color = "black")) +
  coord_fixed(1) +
  theme_classic() +
  theme(
    axis.text.y = element_text(angle = 0, hjust = 1, size = 10, family = "Helvetica", color = "white"),
    axis.text.x = element_text(angle = 0, hjust = 0.5, size = 10, family = "Helvetica", color = "white"),
    axis.ticks = element_blank(),
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    legend.position = c(-0.18,1.02),
    legend.background = element_blank(),
    legend.text = element_text(size = 11))

#ggsave("IUCN_fig3.svg", width = 10, height = 4, dpi = 600)

dev.off()
