
library(bslib)
library(data.table)
library(DT)
library(igraph)
library(png)
library(shiny)
library(shinyBS)
library(tidyverse)
library(visNetwork)

#setwd("~/Documents/MANUSCRIPTS/review_of_reviews/shiny/")

shiny_dat <- readRDS(file = "shiny_data.rds")

path_data <- shiny_dat$data
study_info <- shiny_dat$studies_data
term_groups <- shiny_dat$term_groups
main_terms <- shiny_dat$main_terms
sub1_terms <- shiny_dat$sub1_terms
sub2_terms <- shiny_dat$sub2_terms
taxa <- shiny_dat$taxa
main_colors <- shiny_dat$term_colors

vis_plot <- function(data, detail_level = "broad terms", taxa = "none selected", study_type = "none selected",
                     var_type = "none selected", predictor = "none selected", response = "none selected") {
  
  summ1 <- data
  summ1$all_tags <- paste(summ1$pred_Main_driver, summ1$pred_Sub1, summ1$pred_Sub2, summ1$res_Main_driver, summ1$res_Sub1, summ1$res_Sub2, sep = " ; ")
  
  if (detail_level == "broad terms") { summ1 <- summ1 %>% select(pred_Main_driver, res_Main_driver, pred_Main_driver_ult, res_Main_driver_ult, ArticleID, study_type, taxa_tags, all_tags) }
  if (detail_level == "moderate") { summ1 <- summ1 %>% select(pred_Sub1, res_Sub1, pred_Sub1_ult, res_Sub1_ult, ArticleID, study_type, taxa_tags, all_tags) }
  if (detail_level == "most detailed") { summ1 <- summ1 %>% select(pred_Sub2, res_Sub2, pred_Sub2_ult, res_Sub2_ult, ArticleID, study_type, taxa_tags, all_tags) }
  
  colnames(summ1)[1:4] <- c("from", "to", "ultimate_predictor", "ultimate_response")
  
  if (any(grepl("none selected", taxa)) == FALSE) { summ1 <- summ1[grepl(paste(taxa, collapse = "|"), summ1$taxa_tags, ignore.case = TRUE), ] }
  if (any(grepl("none selected", var_type)) == FALSE) { summ1 <- summ1[grepl(paste(var_type, collapse = "|"), summ1$all_tags, ignore.case = TRUE), ] }
  
  if(study_type == "meta-analysis") { summ1 <- summ1 %>% filter(study_type == "meta-analysis") }
  if(study_type == "review") { summ1 <- summ1 %>% filter(study_type == "review") }
  
  
  g <- graph_from_data_frame(summ1, directed = TRUE)
  
  if (predictor != "none selected") {
    
    target_node <- predictor
    subset_edges <- E(g)[E(g)$ultimate_predictor == target_node]
    subgraph <- subgraph.edges(g, subset_edges)
    #filtered_paths <- pathways[sapply(strsplit(pathways, ">"), function(x) head(x, 1) %in% target_node)]
    #vertices <- unique(unlist(strsplit(filtered_paths, ">")))
    #subgraph <- induced_subgraph(g, vertices)
    #subs <- subcomponent(g, vertices, mode = c("out"))
    #subgraph <- induced_subgraph(g, subs)
    
  }
  
  # if (mediator != "none selected") {
  #    target_node <- mediator
  #   
  #    if (predictor != "none selected") {
  #      tst <- data.frame(as_edgelist(subgraph))
  #      tst1 <- unique(paste(tst$X1, tst$X2, sep = ">"))
  #    
  #      filtered_paths <- tst1[grep(target_node, tst1)]
  #      vertices <- unique(unlist(strsplit(filtered_paths, ">")))
  #      subgraph <- induced_subgraph(subgraph, vertices)
  #      }
  #    
  #    if (predictor == "none selected") {
  #      
  #      filtered_paths <- pathways[sapply(strsplit(pathways, ">"), function(x) tail(x, 1) %in% target_node)]
  #      vertices <- unique(unlist(strsplit(filtered_paths, ">")))
  #      subgraph <- induced_subgraph(g, vertices) }
  # }
  
  if (response != "none selected") {
    target_node <- response
    
    if (predictor != "none selected") {
      
      subset_edges <- E(subgraph)[E(subgraph)$ultimate_response == target_node]
      subgraph <- subgraph.edges(subgraph, subset_edges)
    }
    
    if (predictor == "none selected") {
      
      subset_edges <- E(g)[E(g)$ultimate_response == target_node]
      subgraph <- subgraph.edges(g, subset_edges) }
    
  }
  
  if (predictor == "none selected" & response == "none selected") { subgraph <- g }
  
  #sub <- subcomponent(g, c("size"), mode = c("in"))
  #ERROR message here
  
  if (length(subgraph) == 0) { stop("There are no paths between these variables!") }
  
  edgefreq <- table(attributes(E(subgraph))$vnames)
  edgedf <- array(dim=c(length(edgefreq), 3))
  edgedf[,1] <- factor(append(unlist(lapply(strsplit(names(edgefreq), "\\|"), function(x){x[1]})), 
                              unlist(names(igraph::V(subgraph)))))[1:length(edgefreq)]
  edgedf[,2] <- factor(append(unlist(lapply(strsplit(names(edgefreq), "\\|"), function(x){x[2]})), 
                              unlist(names(igraph::V(subgraph)))))[1:length(edgefreq)]
  edgedf[,3] <- as.numeric(edgefreq)
  edgedf <- as.data.frame(edgedf)
  edgedf[,3] <- as.numeric(edgedf[,3])
  colnames(edgedf) <- c("from", "to", "degree")
  
  nodedat <- igraph::V(subgraph)
  nodedf <- array(dim=c(length(nodedat), 3))
  nodedf[,1] <- as.numeric(factor(names(nodedat)))
  nodedf[,2] <- names(nodedat)
  nodedf[,3] <- rep(1, nrow(nodedf))
  nodedf <- as.data.frame(nodedf)
  nodedf[,3] <- as.numeric(nodedf[,3])
  nodedf[,4] <- sqrt(as.numeric(igraph::strength(subgraph)))
  
  if (detail_level == "broad terms") { colnames(nodedf) <- c("id", "Main_driver", "group", "value") }
  if (detail_level == "moderate") { colnames(nodedf) <- c("id", "Sub1", "group", "value") }
  if (detail_level == "most detailed") { colnames(nodedf) <- c("id", "Sub2", "group", "value") }
  
  suppressMessages(nodedf <- nodedf %>% left_join(main_colors, multiple = "first"))
  colnames(nodedf)[2] <- c("label")
  nodedf$id <- as.integer(nodedf$id)
  
  if (detail_level == "broad terms") { nodedf$Main_driver <-  nodedf$label }
  
  nodedf$color.border <- "black"
  nodedf$color.highlight <- adjustcolor(nodedf$color.background, alpha.f = 0.5)
  nodedf$color.hover <- adjustcolor(nodedf$color.background, alpha.f = 0.5)
  
  # Merge the vertices into a single path
  fin <- list()
  
  fin[[1]] <- visNetwork(nodes = nodedf, edges = edgedf[ edgedf$from != edgedf$to, ], width = "100%") %>%
    visIgraphLayout() %>%
    visNodes(
      shape = "dot",
      font = list(size = 20, bold = TRUE),
      #label=nodedf$label,  
      scaling = list(
        min = min(nodedf$value),
        max = max(nodedf$value), 
        label=list(enabled=F, min=14, max=30))) %>%
    visEdges(
      color = list(color = "lightblue", opacity = 0.5),
      shadow = FALSE
    ) %>%
    #visOptions(
    #  highlightNearest = list(enabled = T, degree = 1, hover = T)
    #) %>%
    visLayout(randomSeed = 22)
  
  fin[[2]] <- summary_data <- data.frame(
    Category = c("# of studies", "# of nodes", "# of edges"),
    Count = c(length(unique(E(subgraph)$ArticleID)),
              vcount(subgraph),
              ecount(subgraph)))
  
  studies_data <- data.frame(ArticleID = E(subgraph)$ArticleID)
  fin[[3]] <- studies_data <- studies_data %>%
    group_by(ArticleID) %>% 
    summarise(edge_count = n()) %>% 
    left_join(study_info, by = "ArticleID") %>% 
    select(ArticleID, title, year, doi, edge_count) %>% 
    arrange(desc(edge_count), ArticleID)
  
  return(fin)
  
}

#vis_plot(path_data)

#Builds the user interface
ui <- fluidPage(
  
  sidebarLayout( 
    
    sidebarPanel(
      
      fluidRow(
        column(12, 
               div(
                 style = "display: inline-block; vertical-align: middle;",
                 div("How to use",
                     style = "font-size: 16px; font-weight: bold; display: inline-block; margin-right: 10px; margin-bottom: 20px;"), # Tutorial text
               ))
      ),
      
      fluidRow(
        column(12, 
               div(
                 style = "display: inline-block; vertical-align: middle;",
                 div(HTML("This tool allows you to examine sub-networks based on different levels of term specificity from our literature search (details in 
                 'Meta-synthesis reveals interconnections among apparent drivers of insect biodiversity loss' by Halsch et al.).
                 Use the dropdown menus below to filter based on different criteria.
                 The info circle contains more information about each variable.<br> <br>This tool has two tabs: one to filter and display the network 
                 and another to view the bibliography that builds it. There is an option to download those citations at the bottom of the 'studies' tab.
                          <br><br>Note: Many combinations will return no results because many combinations do not exist in the data."),
                     style = "font-size: 14px; display: inline-block; margin-right: 10px; margin-bottom: 20px;"), # Tutorial text
               ))
      ),
      
      #These are dropdown menus with the available main drivers and taxa
      fluidRow(
        column(10,selectInput("detail", "Choose a level of resolution for search terms:",
                              c("broad terms", "moderate", "most detailed"),
                              selected = "most detailed")),
        column(1, bsButton("info_button_detail", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px; margin-left: -10px;")),
        column(1)),
      
      fluidRow(
        column(10,selectInput("taxa", "Choose a taxa:",
                              choices =  list(`none selected` = "none selected",
                                              `genus` = taxa[1:5],
                                              `family` = taxa[6:16],
                                              `order` = taxa[17:24],
                                              `function` = taxa[25:28],
                                              `insects` = list(taxa[29])),
                              selected = "none selected",
                              multiple = TRUE)),
        column(1, bsButton("info_button_taxa", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px;")),
        column(1)),
      
      fluidRow(
        column(10,selectInput("study_type", "Choose a type of study:",
                              c("none selected", "meta-analysis", "review"),
                              selected = "none selected")),
        column(1, bsButton("info_button_study_type", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px;")),
      column(1)),
      
      #These dropdown menus are fancier and update based on the results from "detail"
      fluidRow(
        column(10, uiOutput("var_type")),
        column(1, bsButton("info_button_var", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px;")),
        column(1)),
      
      fluidRow(
        column(10, uiOutput("predictor")),
        column(1, bsButton("info_button_pred", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px;")),
        column(1)),
      fluidRow(
        column(10, uiOutput("response")),
        column(1, bsButton("info_button_res", 
                           icon("info-circle"), 
                           style = "width: 30px; height: 30px; line-height: 1; padding: 0px;")),
        column(1)),
      
      #This summarizes main data from the projected network
      plotOutput("legend", height = 200),
      #DTOutput("summary_table")
      #verbatimTextOutput("error_message")
      
    ),
    
    navset_card_underline(
      #title = "Visualizations",
      # Panel with plot ----
      nav_panel("Plot", verbatimTextOutput("error_message"),
                visNetworkOutput(outputId = "net_plot", height = 800),
                tags$div(
                  "Node sizes are proportional to number of occurrences in the network.",
                  style = "position: fixed; bottom: 10px; left: 500px; font-size: 16px; color: black; z-index: 1000; background-color: rgba(255, 255, 255, 0.8); padding: 5px; border-radius: 5px;"
                )),
      
      div(
        DTOutput("summary_table"),
        style = "position: fixed; bottom: 10px; right: 10px; width: 300px; z-index: 1000; background-color: rgba(255, 255, 255, 0.9); padding: 10px; border-radius: 5px;"
      ),
      
      # Panel with table ----
      nav_panel("Studies", div(DTOutput("studies_table")),
                downloadButton('download',"Download these citations"))
    )
    
    #This places the main plot
    #mainPanel(
    #  verbatimTextOutput("error_message"),
    #  visNetworkOutput(outputId = "net_plot", height = 800)
    
    #)
    
  )
)

server <- function(input, output, session) {
  
  #This block updates the choices of filter variables based on "detail"
  output$var_type <- renderUI({
    
    level <- input$detail
    
    choices_var <- switch(level,
                          "broad terms" = list(`predictor` = c("climate", "community interactions", "disturbance", "habitat quality", "industry", "land use change", "non-native species", "other", "overexploitation", "pathogens", "pollution", "urbanization"),
                                                 `response` = c("colony", "genetics", "habitat quality", "individual", "population")),
                          "moderate" = list(`climate` = unique(subset(term_groups, Main_driver == "climate")$Sub1),
                                            `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub1),
                                            `disturbance` = unique(subset(term_groups, Main_driver == "disturbance")$Sub1),
                                            `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub1),
                                            `industry` = unique(subset(term_groups, Main_driver == "industry")$Sub1),
                                            `land use change` = unique(subset(term_groups, Main_driver == "land use change")$Sub1),
                                            `non-native species` = unique(subset(term_groups, Main_driver == "non-native species")$Sub1),
                                            `other` = list(unique(subset(term_groups, Main_driver == "other")$Sub1)),
                                            `overexploitation` = list(unique(subset(term_groups, Main_driver == "overexploitation")$Sub1)),
                                            `pathogens` = list(unique(subset(term_groups, Main_driver == "pathogens")$Sub1)),
                                            `pollution` = unique(subset(term_groups, Main_driver == "pollution")$Sub1),
                                            `urbanization` = unique(subset(term_groups, Main_driver == "urbanization")$Sub1),
                                            `colony` = list(unique(subset(term_groups, Main_driver == "colony")$Sub1)),
                                            `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub1),
                                            `genetics` = list(unique(subset(term_groups, Main_driver == "genetics")$Sub1)),
                                            `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub1),
                                            `individual` = unique(subset(term_groups, Main_driver == "individual")$Sub1),
                                            `population` = unique(subset(term_groups, Main_driver == "population")$Sub1)),
                          "most detailed" = list(`climate` = unique(subset(term_groups, Main_driver == "climate")$Sub2),
                                        `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub2),
                                        `disturbance` = unique(subset(term_groups, Main_driver == "disturbance")$Sub2),
                                        `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub2),
                                        `industry` = unique(subset(term_groups, Main_driver == "industry")$Sub2),
                                        `land use change` = unique(subset(term_groups, Main_driver == "land use change")$Sub2),
                                        `non-native species` = unique(subset(term_groups, Main_driver == "non-native species")$Sub2),
                                        `other` = list(unique(subset(term_groups, Main_driver == "other")$Sub2)),
                                        `overexploitation` = list(unique(subset(term_groups, Main_driver == "overexploitation")$Sub2)),
                                        `pathogens` = list(unique(subset(term_groups, Main_driver == "pathogens")$Sub2)),
                                        `pollution` = unique(subset(term_groups, Main_driver == "pollution")$Sub2),
                                        `urbanization` = unique(subset(term_groups, Main_driver == "urbanization")$Sub2),
                                        `colony` = list(unique(subset(term_groups, Main_driver == "colony")$Sub2)),
                                        `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub2),
                                        `genetics` = list(unique(subset(term_groups, Main_driver == "genetics")$Sub2)),
                                        `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub2),
                                        `individual` = unique(subset(term_groups, Main_driver == "individual")$Sub2),
                                        `population` = unique(subset(term_groups, Main_driver == "population")$Sub2)))
    
    selectInput("var_type", "Choose a variable to filter by:",
                choices = c("none selected", choices_var),
                selected = "none selected",
                multiple = TRUE)
  })
  
  #This block updates the choices of predictor variables based on "detail"
  output$predictor <- renderUI({
    
    level <- input$detail
    
    choices_p <- switch(level,
                        "broad terms" = c("climate", "community interactions", "disturbance", "habitat quality", "industry", "land use change", "non-native species", "other", "overexploitation", "pathogens", "pollution", "urbanization"),
                        "moderate" = list(`climate` = unique(subset(term_groups, Main_driver == "climate")$Sub1),
                                          `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub1),
                                          `disturbance` = unique(subset(term_groups, Main_driver == "disturbance")$Sub1),
                                          `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub1),
                                          `industry` = unique(subset(term_groups, Main_driver == "industry")$Sub1),
                                          `land use change` = unique(subset(term_groups, Main_driver == "land use change")$Sub1),
                                          `non-native species` = unique(subset(term_groups, Main_driver == "non-native species")$Sub1),
                                          `other` = list(unique(subset(term_groups, Main_driver == "other")$Sub1)),
                                          `overexploitation` = list(unique(subset(term_groups, Main_driver == "overexploitation")$Sub1)),
                                          `pathogens` = list(unique(subset(term_groups, Main_driver == "pathogens")$Sub1)),
                                          `pollution` = unique(subset(term_groups, Main_driver == "pollution")$Sub1),
                                          `urbanization` = unique(subset(term_groups, Main_driver == "urbanization")$Sub1)),
                        "most detailed" = list(`climate` = unique(subset(term_groups, Main_driver == "climate")$Sub2),
                                      `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub2),
                                      `disturbance` = unique(subset(term_groups, Main_driver == "disturbance")$Sub2),
                                      `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub2),
                                      `industry` = unique(subset(term_groups, Main_driver == "industry")$Sub2),
                                      `land use change` = unique(subset(term_groups, Main_driver == "land use change")$Sub2),
                                      `non-native species` = unique(subset(term_groups, Main_driver == "non-native species")$Sub2),
                                      `other` = list(unique(subset(term_groups, Main_driver == "other")$Sub2)),
                                      `overexploitation` = list(unique(subset(term_groups, Main_driver == "overexploitation")$Sub2)),
                                      `pathogens` = list(unique(subset(term_groups, Main_driver == "pathogens")$Sub2)),
                                      `pollution` = unique(subset(term_groups, Main_driver == "pollution")$Sub2),
                                      `urbanization` = unique(subset(term_groups, Main_driver == "urbanization")$Sub2)))
    
    selectInput("predictor", "Choose an root predictor:",
                choices = c("none selected", choices_p),
                selected = "none selected",
                multiple = FALSE)
  })
  
  #This block updates the choices of responses based on "detail"
  output$response <- renderUI({
    
    level <- input$detail
    
    choices_r <- switch(level,
                        "broad terms" = c("colony", "community interactions", "genetics", "habitat quality", "individual", "population"),
                        "moderate" = list(`colony` = list(unique(subset(term_groups, Main_driver == "colony")$Sub1)),
                                          `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub1),
                                          `genetics` = list(unique(subset(term_groups, Main_driver == "genetics")$Sub1)),
                                          `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub1),
                                          `individual` = unique(subset(term_groups, Main_driver == "individual")$Sub1),
                                          `population` = unique(subset(term_groups, Main_driver == "population")$Sub1)),
                        "most detailed" = list(`colony` = list(unique(subset(term_groups, Main_driver == "colony")$Sub2)),
                                      `community interactions` = unique(subset(term_groups, Main_driver == "community interactions")$Sub2),
                                      `genetics` = list(unique(subset(term_groups, Main_driver == "genetics")$Sub2)),
                                      `habitat quality` = unique(subset(term_groups, Main_driver == "habitat quality")$Sub2),
                                      `individual` = unique(subset(term_groups, Main_driver == "individual")$Sub2),
                                      `population` = unique(subset(term_groups, Main_driver == "population")$Sub2)))
    selectInput("response", "Choose a terminal response:",
                choices = c("none selected", choices_r),
                selected = "none selected",
                multiple = FALSE)
  })
  
  plt <- reactive({
    tryCatch({
      # Your function call here, for example:
      
      vis_plot(data = path_data,
               detail_level = input$detail,
               taxa = input$taxa,
               study_type = input$study_type,
               var_type = input$var_type,
               predictor = input$predictor,
               response = input$response)
      
    }, error = function(e) {
      
      if (grepl("There are no paths between these variables!", e$message)) {
        # Trigger error message if an error occurs
        NULL }
      else {stop(e)}
    })
  })
  
  output$error_message <- renderPrint({
    if (is.null(plt())) {
      # Print the error message
      cat("There are no paths between these variables!")
    } 
  })
  
  #This block produces the summary table
  output$summary_table <- renderDT({
    datatable(plt()[[2]], options = list(dom = 't'))
  })
  
  output$legend <- renderPlot({
    img <- readPNG("legend.png")
    grid::grid.raster(img)
    
  })
  
  #This block produces the plot
  output$net_plot <- renderVisNetwork({
    
    plt()[[1]]
    
  })
  
  output$studies_table <- renderDT({
    datatable(plt()[[3]], options = list(scrollY = "600px", paging = FALSE, dom = 'ft'))
  })
  
  output$download <- downloadHandler(
    filename = function(){"citations.csv"}, 
    content = function(fname){
      write.csv(plt()[[3]], fname, row.names = F)
    }
  )
  
  observeEvent(input$info_button_detail, {
    showModal(
      modalDialog(
        title = "Resolution",
        "Terms from reviews are grouped by their similarities. Increasing the resolution will make
        nodes more descriptive, but also produce more nodes.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$info_button_taxa, {
    showModal(
      modalDialog(
        title = "Taxa",
        "This builds networks using only paths that specify a particular taxa. Multiple entries use an OR operator
        and will display networks of either of the selected taxa.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$info_button_study_type, {
    showModal(
      modalDialog(
        title = "Study type",
        "This builds networks using only paths from selected types of studies.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$info_button_var, {
    showModal(
      modalDialog(
        title = "Variable type",
        "This builds networks using only paths that include a certain variable of interest. Multiple entries use an OR operator
        and will display networks that include either type of stressor.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$info_button_pred, {
    showModal(
      modalDialog(
        title = "Root predictor",
        "This builds networks using only paths that originate with the selected variable.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$info_button_res, {
    showModal(
      modalDialog(
        title = "Terminal response",
        "This builds networks using only paths that end at the selected variable.",
        easyClose = TRUE
      )
    )
  })
  
  observeEvent(input$taxa, {
    if ("none selected" %in% input$taxa && length(input$taxa) > 1) {
      updateSelectInput(
        session,
        inputId = "taxa",
        selected = setdiff(input$taxa, "none selected")
      )
    }
  })
  
  observeEvent(input$var_type, {
    if ("none selected" %in% input$var_type && length(input$var_type) > 1) {
      updateSelectInput(
        session,
        inputId = "var_type",
        selected = setdiff(input$var_type, "none selected")
      )
    }
  })
  
  output$selected_options <- renderPrint({
    input$options
  })
  
}

shinyApp(ui = ui, server = server)

